# Space-Tearing Claw

Minecraft Java Edition 1.21.1 / Fabric.

## What is in this prototype?

This is the first playable version of the legendary Space-Tearing Claw.

### Normal right-click: Tear Space
- Raycasts up to 28 blocks.
- Opens a visual dimensional tear at the departure and arrival points.
- Teleports the player to the target.
- Refuses unsafe solid-block exits.
- Cooldown: 45 ticks (2.25 seconds).
- Costs 3 durability.

### Sneak + right-click: Space-Tearing Tornado
- Creates a roughly 9-second tornado.
- Pulls nearby living entities inward.
- Adds swirling motion.
- Deals periodic magic damage.
- Emits wind/cloud particles, portal effects, gold/silver sparks and animated-looking space slashes.
- Collapses into a final dimensional rift.
- Cooldown: 220 ticks (11 seconds).
- Costs 12 durability.

### Normal melee hit
- Adds an extra magic-style visual slash.
- Adds a short attack cooldown.

## Getting the item

In a creative world:
`/give @s riftclaw:space_tearing_claw`

It is also added to the Combat creative tab.

## Build

Requires JDK 21.

From the project directory:

`./gradlew build`

The finished JAR will be in:

`build/libs/`

The project targets:
- Minecraft 1.21.1
- Fabric Loader 0.16.5
- Fabric API 0.116.17+1.21.1
- Yarn 1.21.1+build.3
- Fabric Loom 1.7.4

## Installing on Zalith Launcher 2

Install a Minecraft 1.21.1 Fabric instance, then put the built JAR into that instance's `mods` folder.

Fabric API is also required.

Zalith Launcher 2 supports installing Fabric and Fabric API directly through its add-ons flow.
