package com.example.riftclaw;

import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;

import java.util.Random;

public final class RiftVisuals {
    private static final DustParticleEffect GOLD = new DustParticleEffect(0xFFD86A, 1.1f);
    private static final DustParticleEffect SILVER = new DustParticleEffect(0xDDE7F2, 1.0f);
    private static final DustParticleEffect VOID = new DustParticleEffect(0x6B32FF, 1.15f);

    private RiftVisuals() {}

    public static void rift(ServerWorld world, Vec3d center, double scale) {
        Random random = world.getRandom();

        for (int i = 0; i < 34; i++) {
            double angle = random.nextDouble() * Math.PI * 2.0;
            double r = scale * (0.55 + random.nextDouble() * 0.75);

            double x = center.x + Math.cos(angle) * r;
            double y = center.y + (random.nextDouble() - 0.5) * scale * 1.9;
            double z = center.z + Math.sin(angle) * r;

            ParticleEffect effect = (i % 4 == 0) ? GOLD : (i % 3 == 0 ? SILVER : VOID);

            world.spawnParticles(
                    effect,
                    x, y, z,
                    1,
                    (center.x - x) * 0.06,
                    (center.y - y) * 0.06,
                    (center.z - z) * 0.06,
                    0.0
            );
        }

        for (int i = 0; i < 10; i++) {
            world.spawnParticles(
                    ParticleTypes.PORTAL,
                    center.x + (random.nextDouble() - 0.5) * scale,
                    center.y + (random.nextDouble() - 0.5) * scale,
                    center.z + (random.nextDouble() - 0.5) * scale,
                    1,
                    0, 0, 0,
                    0.15
            );
        }
    }

    public static void slash(ServerWorld world, Vec3d center, double size) {
        Random random = world.getRandom();

        double yaw = random.nextDouble() * Math.PI * 2.0;
        double pitch = (random.nextDouble() - 0.5) * 0.9;

        Vec3d axis = new Vec3d(
                Math.cos(yaw),
                Math.sin(pitch),
                Math.sin(yaw)
        ).normalize();

        Vec3d perpendicular = new Vec3d(-axis.z, 0.25, axis.x).normalize();

        Vec3d start = center.subtract(axis.multiply(size));
        Vec3d end = center.add(axis.multiply(size));

        int pieces = 7;
        for (int i = 0; i <= pieces; i++) {
            double t = i / (double) pieces;
            double curve = Math.sin(t * Math.PI) * size * 0.28;

            Vec3d p = start.lerp(end, t).add(perpendicular.multiply(curve));

            world.spawnParticles(
                    i % 2 == 0 ? SILVER : VOID,
                    p.x, p.y, p.z,
                    1,
                    0, 0, 0,
                    0.0
            );
        }

        world.spawnParticles(ParticleTypes.CRIT, center.x, center.y, center.z, 2, 0.12, 0.12, 0.12, 0.02);
    }

    public static void tornado(ServerWorld world, Vec3d center, double radius, double height, int age) {
        Random random = world.getRandom();

        for (int i = 0; i < 26; i++) {
            double t = random.nextDouble();
            double y = t * height;
            double localRadius = radius * (0.25 + t * 0.8);
            double angle = age * 0.22 + t * 8.0 + random.nextDouble() * 1.2;

            Vec3d p = center.add(
                    Math.cos(angle) * localRadius,
                    y,
                    Math.sin(angle) * localRadius
            );

            world.spawnParticles(
                    i % 4 == 0 ? GOLD : ParticleTypes.CLOUD,
                    p.x, p.y, p.z,
                    1,
                    0.06, 0.06, 0.06,
                    i % 4 == 0 ? 0.0 : 0.015
            );
        }

        // Space slashes inside the wind column.
        for (int i = 0; i < 7; i++) {
            double t = random.nextDouble();
            double y = t * height;
            double localRadius = radius * random.nextDouble();
            double angle = age * 0.15 + random.nextDouble() * Math.PI * 2.0;

            Vec3d p = center.add(
                    Math.cos(angle) * localRadius,
                    y,
                    Math.sin(angle) * localRadius
            );

            slash(world, p, 0.25 + random.nextDouble() * 0.55);
        }

        if (age % 12 == 0) {
            world.spawnParticles(
                    ParticleTypes.REVERSE_PORTAL,
                    center.x, center.y + height * 0.5, center.z,
                    14,
                    radius * 0.25, height * 0.35, radius * 0.25,
                    0.08
            );
        }
    }
}
