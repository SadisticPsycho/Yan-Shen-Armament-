package com.example.riftclaw;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class SpaceTearingClawItem extends Item {
    private static final int TELEPORT_COOLDOWN = 45;
    private static final int TORNADO_COOLDOWN = 220;
    private static final double MAX_TELEPORT_DISTANCE = 28.0;

    public SpaceTearingClawItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);

        if (user.getItemCooldownManager().isCoolingDown(this)) {
            return ActionResult.FAIL;
        }

        // Sneak + use = summon the dimensional tornado.
        if (user.isSneaking()) {
            if (!world.isClient && world instanceof ServerWorld serverWorld) {
                Vec3d center = findTornadoTarget(serverWorld, user);
                SpaceTornadoManager.add(serverWorld, center, user);

                serverWorld.playSound(
                        null,
                        user.getX(), user.getY(), user.getZ(),
                        SoundEvents.ENTITY_ENDER_DRAGON_GROWL,
                        SoundCategory.PLAYERS,
                        0.65f,
                        1.55f
                );

                user.getItemCooldownManager().set(this, TORNADO_COOLDOWN);
                stack.damage(12, user, LivingEntity.getSlotForHand(hand));
            }

            user.swingHand(hand);
            return ActionResult.SUCCESS;
        }

        // Normal use = tear open space and teleport.
        if (!world.isClient && world instanceof ServerWorld serverWorld) {
            Vec3d destination = findTeleportTarget(serverWorld, user);

            // Make sure we don't land inside a solid block.
            BlockPos feet = BlockPos.ofFloored(destination);
            BlockPos head = feet.up();

            if (!serverWorld.getBlockState(feet).getCollisionShape(serverWorld, feet).isEmpty()
                    || !serverWorld.getBlockState(head).getCollisionShape(serverWorld, head).isEmpty()) {
                user.sendMessage(net.minecraft.text.Text.literal("The tear cannot find a safe exit."), true);
                return ActionResult.FAIL;
            }

            createRiftBurst(serverWorld, user.getPos().add(0, 1.0, 0), destination);

            user.requestTeleport(destination.x, destination.y, destination.z);
            user.getItemCooldownManager().set(this, TELEPORT_COOLDOWN);
            stack.damage(3, user, LivingEntity.getSlotForHand(hand));

            serverWorld.playSound(
                    null,
                    destination.x, destination.y, destination.z,
                    SoundEvents.ENTITY_ENDERMAN_TELEPORT,
                    SoundCategory.PLAYERS,
                    1.0f,
                    0.75f
            );
        }

        user.swingHand(hand);
        return ActionResult.SUCCESS;
    }

    private static Vec3d findTeleportTarget(ServerWorld world, PlayerEntity user) {
        HitResult result = user.raycast(MAX_TELEPORT_DISTANCE, 1.0f, false);

        if (result.getType() == HitResult.Type.BLOCK) {
            BlockHitResult blockHit = (BlockHitResult) result;
            Direction side = blockHit.getSide();
            Vec3d normal = new Vec3d(side.getOffsetX(), side.getOffsetY(), side.getOffsetZ());

            // Step just outside the face that was hit.
            return blockHit.getPos().add(normal.multiply(1.35));
        }

        Vec3d direction = user.getRotationVec(1.0f).normalize();
        return user.getPos().add(direction.multiply(MAX_TELEPORT_DISTANCE));
    }

    private static Vec3d findTornadoTarget(ServerWorld world, PlayerEntity user) {
        HitResult result = user.raycast(18.0, 1.0f, false);

        if (result.getType() == HitResult.Type.BLOCK) {
            return result.getPos().add(0, 0.2, 0);
        }

        return user.getPos().add(user.getRotationVec(1.0f).normalize().multiply(10.0));
    }

    private static void createRiftBurst(ServerWorld world, Vec3d from, Vec3d to) {
        RiftVisuals.rift(world, from, 1.2);
        RiftVisuals.rift(world, to, 1.5);

        Vec3d delta = to.subtract(from);
        int steps = Math.max(8, (int) (delta.length() * 1.4));

        for (int i = 0; i <= steps; i++) {
            double t = i / (double) steps;
            Vec3d p = from.lerp(to, t);
            RiftVisuals.slash(world, p, 0.45 + 0.35 * Math.sin(t * Math.PI));
        }
    }

    @Override
    public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        if (attacker instanceof PlayerEntity player && !player.getItemCooldownManager().isCoolingDown(this)) {
            target.damage(attacker.getDamageSources().player(player), 4.0f);
            RiftVisuals.slash((ServerWorld) player.getWorld(), target.getPos().add(0, 1, 0), 0.65);
            player.getItemCooldownManager().set(this, 6);
        }
        return true;
    }
}
