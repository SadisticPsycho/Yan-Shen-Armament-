package com.example.riftclaw;

import net.minecraft.entity.LivingEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

public final class SpaceTornadoManager {
    private static final List<Tornado> TORNADOES = new ArrayList<>();

    private SpaceTornadoManager() {}

    public static void add(ServerWorld world, Vec3d center, ServerPlayerEntity owner) {
        TORNADOES.add(new Tornado(world, center, owner.getUuid()));
        RiftVisuals.rift(world, center, 1.5);
    }

    public static void tick(net.minecraft.server.MinecraftServer server) {
        Iterator<Tornado> iterator = TORNADOES.iterator();

        while (iterator.hasNext()) {
            Tornado tornado = iterator.next();

            if (tornado.age++ >= tornado.maxAge) {
                RiftVisuals.rift(tornado.world, tornado.center, 2.2);
                iterator.remove();
                continue;
            }

            double progress = tornado.age / (double) tornado.maxAge;
            double radius = 2.0 + Math.sin(Math.min(1.0, progress) * Math.PI) * 3.8;
            double height = 4.0 + Math.sin(Math.min(1.0, progress) * Math.PI) * 5.0;

            // Pull nearby living entities toward the core.
            Box box = new Box(
                    tornado.center.x - radius,
                    tornado.center.y - 1,
                    tornado.center.z - radius,
                    tornado.center.x + radius,
                    tornado.center.y + height,
                    tornado.center.z + radius
            );

            for (LivingEntity entity : tornado.world.getEntitiesByClass(
                    LivingEntity.class,
                    box,
                    e -> e.isAlive() && !e.getUuid().equals(tornado.owner)
            )) {
                Vec3d toCenter = tornado.center.add(0, height * 0.45, 0).subtract(entity.getPos());
                double distance = Math.max(1.0, toCenter.length());

                Vec3d pull = toCenter.normalize().multiply(0.055 + 0.12 / distance);
                Vec3d swirl = new Vec3d(-toCenter.z, 0, toCenter.x).normalize().multiply(0.075);

                entity.addVelocity(pull.x, 0.035 + Math.min(0.10, 0.015 / distance), pull.z);
                entity.addVelocity(swirl.x, 0, swirl.z);

                if (tornado.age % 10 == 0) {
                    entity.damage(tornado.world.getDamageSources().magic(), 2.5f);
                }
            }

            // Visual layers.
            if (tornado.age % 2 == 0) {
                RiftVisuals.tornado(tornado.world, tornado.center, radius, height, tornado.age);
            }
        }
    }

    private static final class Tornado {
        final ServerWorld world;
        final Vec3d center;
        final UUID owner;
        int age = 0;
        final int maxAge = 180;

        Tornado(ServerWorld world, Vec3d center, UUID owner) {
            this.world = world;
            this.center = center;
            this.owner = owner;
        }
    }
}
