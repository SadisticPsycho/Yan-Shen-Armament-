package com.example.riftclaw;

import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public final class RiftClawItems {
    public static final Item SPACE_TEARING_CLAW = Registry.register(
            Registries.ITEM,
            RiftClawMod.id("space_tearing_claw"),
            new SpaceTearingClawItem(new Item.Settings()
                    .maxCount(1)
                    .maxDamage(2031))
    );

    private RiftClawItems() {}

    public static void init() {
        // Class loading triggers registration.
    }
}
