package com.example.riftclaw;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class RiftClawMod implements ModInitializer {
    public static final String MOD_ID = "riftclaw";

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        RiftClawItems.init();

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries ->
                entries.add(RiftClawItems.SPACE_TEARING_CLAW));

        ServerTickEvents.END_SERVER_TICK.register(SpaceTornadoManager::tick);
    }
}
